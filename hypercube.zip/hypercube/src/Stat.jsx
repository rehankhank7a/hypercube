import React from 'react'
import Footer from './Footer'
import { Link } from 'react-router-dom'

const Stat = () => {
  return (
   <>
   Under Process
   <Link to='/'>Go Back</Link>
    
   </>
  )
}

export default Stat