import React from 'react'
import g from '../public/g.png'
import coins from '../public/coins.gif'
import flip from '../public/flip.gif'
const BackDrop = ({close}) => {
  return (
    <>
    <div style={{display:'flex',justifyContent:'center',alignItems:'end', height:'100vh',zIndex:'4000',backgroundColor:'#00000094',top:'0', left:'0', width:window.innerWidth, position:'absolute'}}>

  <div style={{padding:'30px', backgroundColor:'#242424', display:'flex', justifyContent:'center', flexDirection:'column', alignItems:'center', width:window.innerWidth}}>
    <img src={flip} height={100} width={100} alt="" />
    {/* <img src={coins} height={100} alt="" /> */}
  <div  className='button' onClick={close} style={{padding:'10px', background:"#F3C162", color:'white', display:'flex', justifyContent:'center', alignItems:"center", cursor:'pointer', border:'1px solid #434343', borderRadius:'8px'}}><img src={g} alt="" height={"20px"} width={"20px"} />&nbsp; Claim Now</div>


  </div>

    </div>
    
    </>
  )
}

export default BackDrop