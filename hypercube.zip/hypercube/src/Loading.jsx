import React from 'react'

import loader from '../public/spinner.gif'

const Loading = () => {
  return (
  
    <>
    <div style={{display:'flex', justifyContent:'center', alignItems:'center'}}>
    <img src={loader} alt="" height={"30px"} />
    </div>
    
  
    
    
    </>
  )
}

export default Loading