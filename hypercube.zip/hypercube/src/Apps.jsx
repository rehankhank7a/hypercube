import React from 'react'
import { useState , useEffect} from 'react'
import './App.css'
import Loading from './Loading'
import coin from '../public/coin2.png'
import c from '../public/c.png'
import g from '../public/g.png'
import f from '../public/f.png'
import BackDrop from './BackDrop'
import t from '../public/t.png'
import s from '../public/s.png'
import r from '../public/r.png'
import Footer from './Footer'

const Apps = () => {
  const [backdrop, setbackdrop] = useState(1);
  const closebackdrop =()=>{
    setbackdrop(0)

  }
    const [coin , setCoin]=useState(0)
    const [showComponentA, setShowComponentA] = useState(true);

    const [username, setUsername] = useState('');

    useEffect(() => {
      // Check if Telegram WebApp object is available
      if (window.Telegram && window.Telegram.WebApp) {
        const telegram = window.Telegram.WebApp;
        // Get user information from Telegram Web App
        const user = telegram.initDataUnsafe?.user;
        if (user) {
          setUsername(user.username);
       console.log("this is user ", user.username)
        }
      }
    }, []);
    useEffect(() => {
      // Set timeout to hide Component A after 5 seconds
      const timeout = setTimeout(() => {
        setShowComponentA(false);
      }, 600); // 5000 ms = 5 seconds
  
      // Clean up the timeout to prevent memory leaks
      return () => clearTimeout(timeout);
    }, []);
    const getCoin = ()=>{
   
     localStorage.setItem('coin',coin + 1043 );
     setCoin(prevCoin => prevCoin + 1043);
     }
   useEffect(()=>{
    let coin = localStorage.getItem('coin')
   if(coin ){
    setCoin(parseInt(coin))

   }else{
    localStorage.setItem('coin',0 )
   }
   },[])
   
   
  useEffect(() => {
    const interval = setInterval(() => {
      // Update coin state by adding 22 to current value
      // localStorage.setItem('coin',coin + 22 );
      setCoin(prevCoin => prevCoin + 22);
    }, 1000); // 1000 ms = 1 second

    // Clean up the interval to prevent memory leaks
    return () => clearInterval(interval);
  }, []);

  

  const [animationCount, setAnimationCount] = useState(0);
  const flyingImageURL = c; // Replace with your flying image URL
  const imageSize = 20; 
  const animate = (event) => {
    const { clientX, clientY } = event;

    // Create a new image element
    const image = new Image();
    image.src = flyingImageURL;
    image.classList.add("coin");
    image.style.width = `${imageSize}px`; // Set width of the image
    image.style.height = `${imageSize}px`; // Set height of the image

    // Position the image at the click coordinates
    image.style.left = `${clientX - imageSize / 2}px`;
    image.style.top = `${clientY}px`;


    // Append the image to the document body
    document.body.appendChild(image);

    // Animate the image
    const animationName = animationCount % 2 === 0 ? "flyingEven" : "flyingOdd";
    image.style.animation = `${animationName} 0.8s linear`;

    // Remove the image from the DOM after animation ends
    image.addEventListener("animationend", () => {
      document.body.removeChild(image);
    });

    // Increment animation count for alternating animations
    setAnimationCount(prevCount => prevCount + 1);
  };
  

     return (
       <>


    {showComponentA ? (
        <Loading />
      ) : (
        <div  style={{display:'flex', flexDirection:"column", justifyContent:'center', alignItems:'center', gap:'20px', border:'', padding:'60px 40px 60px 40px' , borderRadius:'8px'}}>
          {backdrop?<BackDrop close={closebackdrop}></BackDrop>:<></>}
   <div style={{display:'flex', justifyContent:'center', alignItems:'center', gap:'8px'}}>
   
     
   <img src={g} alt="" height={"30px"} width={"30px"} />
         <div style={{fontSize:'30px', fontWeight:'600', color:'white'}}>{coin && coin} M</div>
   
   </div>
        
        <div style={{color:'grey'}}>legendary {username && username}  </div>
   
          <div style={{height:'200px'}}></div>
          <div onClick={animate} className='coin'>
        <img style={{paddingTop:''}} onClick={getCoin}  src={c} alt="" height={"200px"} width={"200px"} />
        </div>
       <div  className='button' onClick={getCoin} style={{padding:'10px', background:"", color:'white', display:'flex', justifyContent:'center', alignItems:"center", cursor:'pointer', border:'1px solid #434343', borderRadius:'8px'}}><img src={g} alt="" height={"20px"} width={"20px"} />&nbsp; 1000 GET</div>
   
   
       <Footer />
   
         </div>
      )}


      
      
       </>
  )
}

export default Apps