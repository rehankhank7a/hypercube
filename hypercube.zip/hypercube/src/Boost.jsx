import React from 'react'
import Footer from './Footer'
import { Link } from 'react-router-dom'

const Boost = () => {
  return (
    <>
   <div style={{display:'flex', flexDirection:'column', gap:'20px'}}>

    <div>Wallet Will be available Soon</div>
    <input type="text" placeholder='Enter Wallet Address e.g 0x9Acc' />

    <div  className='button'  style={{padding:'10px', background:"", color:'white', display:'flex', justifyContent:'center', alignItems:"center", cursor:'pointer', border:'1px solid #434343', borderRadius:'8px'}}> Withdraw</div>
   </div>

<Footer></Footer>
    
    </>
  )
}

export default Boost