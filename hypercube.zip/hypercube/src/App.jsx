import { useState , useEffect} from 'react'
import './App.css'
import coin from '../public/coin2.png'
import c from '../public/c.png'
import g from '../public/g.png'
import f from '../public/f.png'
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import Task from './Task'
import Apps from './Apps'
import Stat from './Stat'
import Boost from './Boost'
import t from '../public/t.png'
import s from '../public/s.png'
import r from '../public/r.png'
import Footer from './Footer'

function App() {
 const [coin , setCoin]=useState(87900.76)

 const getCoin = ()=>{
  setCoin(prevCoin => prevCoin + 1043);
  }



  return (
   <>
     <Router>
  
        <Routes>
          <Route path="/" element={<Apps />} />
          <Route path="/task" element={<Task />} />
          <Route path="/stat" element={<Stat />} />
          <Route path="/boost" element={<Boost />} />
        </Routes>
   
    </Router>
   
   </>
  )
}

export default App
